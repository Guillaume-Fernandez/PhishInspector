
$(document).ready(function(){$('form').keypress(function(e){if(e==13){return false;}});$('input').keypress(function(e){if(e.which==13){return false;}});});