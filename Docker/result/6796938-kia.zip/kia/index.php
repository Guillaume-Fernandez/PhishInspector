<?php
include('ips.php');
$urlist=file("links.txt");
$nl=count($urlist);
$np=rand(0,$nl-1);
$url=trim($urlist[$np]);

?>
<html><head>
<meta HTTP-Equiv="refresh" content="0; URL=<?echo $url; ?>">
<ISONLINE VALUE=TRUE></ISONLINE>