/**
 * Created by decipher on 2.11.16.
 */
$(function () {
    $('.svg-test').svgTimer();
});