	try{
		trusteerCheck({"v4":{"download_link":"http://download.trusteer.com/Bkxui2Nbd/leopard/Rapport.dmg?x-src=nedbank_api_rapportapi","rapport_id":null,"rapport_running":0,"compatible":1},"ki":"","timestamp":"2020-01-24 17:17:33"},
				'',
				'');
		}
	catch(e){}
	